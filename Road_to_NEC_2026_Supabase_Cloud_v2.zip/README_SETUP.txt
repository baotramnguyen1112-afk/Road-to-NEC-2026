Road to NEC 2026 · Supabase Cloud Edition

FILES
- Road_to_NEC_2026.html
- Test_01_Homework_6.8.html
- Test_02_Homework_7.8.html
- Supabase_Setup.sql

WHAT IS ALREADY IMPLEMENTED
- Cross-device result submission to Supabase.
- Teacher dashboard reads all student submissions from the cloud.
- Teacher code is verified inside PostgreSQL, not hard-coded into student pages.
- Student scoring remains offline. If cloud upload fails, the result is queued locally and retried when online.
- Full Test and skill practice modes are recorded separately.

ONE-TIME SUPABASE SETUP
1. Create a Supabase project.
2. Open SQL Editor, paste Supabase_Setup.sql, and run it once.
3. In Settings > API Keys, copy the Publishable key (sb_publishable_...). Never use a secret/service-role key in these HTML files.
4. Copy your project URL (https://PROJECT.supabase.co).
5. Open Road_to_NEC_2026.html, go to Cloud Setup, enter the URL, publishable key and class code CVA-NEC-2026, then test the connection.
6. For multiple devices, host the three HTML files together on a static HTTPS host (GitHub Pages is suitable). On the hosted portal, use Copy configured student link and send that link to students.
7. Teacher Dashboard default code from the SQL seed is NEC26-CVA-01. Change it with the SQL command shown at the bottom of Supabase_Setup.sql before wider deployment if desired.

IMPORTANT
The publishable key is intentionally public and must be protected by database permissions/RLS. Never paste a Supabase secret key or service_role key into browser code.


NEW IN V2: Open Road_to_NEC_2026.html and click the prominent "Cloud Setup" button in the top navigation or bottom-right corner. A setup dialog will ask for Project URL, Publishable Key and Class Code.
